function calculate() {
  var myBox1 = document.getElementById("box1").value;
  var myBox2 = document.getElementById("box2").value;
  var operator = document.getElementById("operator").value;
  var result = document.getElementById("result");
  var myResult;

  if (operator == "+") {
    myResult = Number(myBox1) + Number(myBox2);
  } else if (operator == "-") {
    myResult = Number(myBox1) - Number(myBox2);
  } else if (operator == "*") {
    myResult = Number(myBox1) * Number(myBox2);
  } else if (operator == "/") {
    myResult = Number(myBox1) / Number(myBox2);
  }

  result.value = myResult;
}